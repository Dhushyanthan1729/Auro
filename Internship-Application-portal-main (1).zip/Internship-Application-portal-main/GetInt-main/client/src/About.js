
const About = ()=>{
    return (
        <div className="about">
            <p>This site has been designed and developed by two students of IIT Guwahati, Amrisha Vardiya and Shivam Agrawal.</p>
        </div>
    );
}

export default About;